function Header({ onRegistrarClick }) {
  return (
    <header className="header">
      <button className="pill menu">MENU</button>
      <button className="pill contact">CONTACTO</button>
      <button className="pill register">REGISTRAR</button>
    </header>
  );
}

export default Header;
