import { useState } from "react";

function Login({ goToRegister, onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    onLogin(email, password);
  };

  return (
    <form className="login-form" onSubmit={handleSubmit}>
      <h1>SP00KY COOKIE</h1>
      <h2>Inicio de sesión</h2>
      <input
        type="email"
        placeholder="Correo"
        value={email}
        onChange={e => setEmail(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Contraseña"
        value={password}
        onChange={e => setPassword(e.target.value)}
        required
      />
      <button type="submit">ENTRAR</button>
      <div>
        <button type="button" onClick={goToRegister}>REGISTRARSE</button>
      </div>
    </form>
  );
}
export default Login;
