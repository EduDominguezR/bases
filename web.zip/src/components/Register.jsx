import { useState } from "react";

function Register({ goToLogin, onRegister }) {
  const [form, setForm] = useState({
    email: '',
    nombre: '',
    telefono: '',
    direccion: '',
    password: '',
  });

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    onRegister(form);
  };

  return (
    <form className="register-form" onSubmit={handleSubmit}>
      <h2>REGISTRO</h2>
      <h1>SP00KY COOKIE</h1>
      <input
        type="email"
        name="email"
        placeholder="Correo"
        value={form.email}
        onChange={handleChange}
        required
      />
      <input
        name="nombre"
        placeholder="Nombre completo"
        value={form.nombre}
        onChange={handleChange}
        required
      />
      <input
        name="telefono"
        placeholder="Teléfono"
        value={form.telefono}
        onChange={handleChange}
      />
      <input
        name="direccion"
        placeholder="Dirección"
        value={form.direccion}
        onChange={handleChange}
      />
      <input
        type="password"
        name="password"
        placeholder="Contraseña"
        value={form.password}
        onChange={handleChange}
        required
      />
      <button type="submit">REGISTRARSE</button>
      <div>
        <button type="button" onClick={goToLogin}>Ir a iniciar sesión</button>
      </div>
    </form>
  );
}
export default Register;
