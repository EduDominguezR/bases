function MainContent() {
  return (
    <main className="main-content">
      <div className="cookie-wrap">
        <img src="/cookie.png" alt="galletas" className="cookie-img" />
        <div className="divider" />
        
      </div>
    </main>
  );
}

export default MainContent;
