import Header from './components/Header.jsx';
import MainContent from './components/MainContent.jsx';
import { useState } from "react";
import Login from './components/Login.jsx';
import Register from './components/Register.jsx';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const handleLogin = async (email, password) => {
    // Conexión a backend (ejemplo usando fetch)
    const res = await fetch('http://localhost:4000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (res.ok) {
      setIsLoggedIn(true);
      setShowRegister(false);
    } else {
      alert('Usuario o contraseña incorrectos');
    }
  };

  const handleRegister = async (userData) => {
    // Conectar a backend
    const res = await fetch('http://localhost:4000/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    if (res.ok) {
      // Puedes iniciar sesión automático o redirigir a login
      setShowRegister(false);
    } else {
      alert('Registro fallido');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setShowRegister(false);
    // Aquí podrías limpiar token/cookie si usas sesiones
  };

  const handleRegistrarClick = () => {
    if (!isLoggedIn) setShowRegister(true);
  };

  return (
    <div className="App">
      <Header onRegistrarClick={handleRegistrarClick} />
      {/* Visualización condicional */}
      {isLoggedIn ? (
        <div>
          <h2>Bienvenido, has iniciado sesión</h2>
          <button onClick={handleLogout}>Cerrar sesión</button>
          <MainContent />
        </div>
      ) : showRegister ? (
        <Register 
          goToLogin={() => setShowRegister(false)} 
          onRegister={handleRegister} 
        />
      ) : (
        <Login 
          goToRegister={() => setShowRegister(true)} 
          onLogin={handleLogin}
        />
      )}
    </div>
  );
}

export default App;
