function Header() {
return (
<header className="header">
<div className="logo">🍪 <span>SpookyCookie</span></div>
<nav className="nav">
<button className="pill ghost">Menu</button>
<button className="pill outline">Contacto</button>
<button className="pill primary">Registrar</button>
</nav>
</header>
);
}