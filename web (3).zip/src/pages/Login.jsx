import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [usuario, setUsuario] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí va la lógica de autenticación si la añades
  };

  const handleRegister = () => {
    navigate("/register");
  };

  return (
    <div className="login-page">
      <form className="login-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Usuario"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button className="btn btn-primary" type="submit">Entrar</button>
      </form>
      <div style={{ marginTop: "24px", textAlign: "center" }}>
        <span>Si no has iniciado sesión, </span>
        <button
          style={{
            background: "none",
            border: "none",
            color: "#D182A6",
            textDecoration: "underline",
            cursor: "pointer",
            fontSize: "1em"
          }}
          onClick={handleRegister}
        >
          regístrate
        </button>
      </div>
    </div>
  );
}

export default Login;
