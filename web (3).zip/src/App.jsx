import React from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import "./App.css";

function Header() {
  const navigate = useNavigate();
  return (
    <header className="header">
      <div className="logo">🍪 <span>SpookyCookie</span></div>
      <nav className="nav">
        <button className="pill ghost">Menu</button>
        <button className="pill outline">Contacto</button>
        <button className="pill primary" onClick={() => navigate("/login")}>
          iniciar sesion
        </button>
      </nav>
    </header>
  );
}

function MainContent() {
  return (
    <main className="main-content" role="main">
      <section className="card">
        <figure className="cookie-card" aria-hidden>
          <div className="cookie-orbit">
            <img src="/cookie.png" alt="Galleta Spooky" className="cookie-img" />
            <div className="crumbs" aria-hidden />
          </div>
        </figure>
        <div className="card-body">
          <h1 className="title"><span className="accent">Spooky</span> Cookie</h1>
        </div>
      </section>
    </main>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <Header />
      <Routes>
        <Route path="/" element={<MainContent />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
      <footer className="footer">
        © {new Date().getFullYear()} SpookyCookie — Hecho con 🍪 y CSS
      </footer>
    </div>
  );
}
